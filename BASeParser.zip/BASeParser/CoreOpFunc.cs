﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.Remoting;
using System.Runtime.InteropServices;
namespace BASeParser
{
    internal class CoreOpFunc : IEvalPlugin

    {
        private const String HandledFunctionString = " sin cos tan sqr array createobject store log round ";
        private const String ArrayAwareFunctions = " store "; //array aware functions are functions that can accept an array. otherwise, the array is flattened and the function called
                                                                //with each value as a parameter.
        private const String HandledOperatorString = " - + * / ^ $$ \\ DIV IN ";
        private const String HandledPostfixOps = " ! ";
        private const String HandledPrefixOps = " - ";
        private const String ArrayOperators = " IN ";
        private List<PluginEvent> mPluginEvents;

        public CoreOpFunc(PluginEvent eventdelegate)
        {
            mPluginEvents = new List<PluginEvent>();
            mPluginEvents.Add(eventdelegate);
        }


        private double factorial(int N)
        {
            if (N < 0) throw new InvalidOperationException("cannot take the factorial of a negative number.");
            if (N == 0) return 1;
            return N * factorial(N - 1);


        }

        #region IEvalPlugin Members

        public object HandleOperator(string Operator, object OpA, object OpB)
        {
            Debug.Print("HandleOperator:" + Operator + " OpA:" + OpA + " OpB:" + OpB);

            Type OpAType = OpA.GetType();
            Type OpBType = OpB.GetType();

            MethodInfo[] OpAMembers = OpAType.GetMethods();
            MethodInfo[] basemembers = OpAType.BaseType.GetMethods();
            MethodInfo[] OpAOperators = OpAType.GetMethods().Where((a) => a.Name.StartsWith("operator")).ToArray();
            MethodInfo[] OpBOperators = OpBType.GetMethods().Where((a) => a.Name.StartsWith("operator")).ToArray();
            Object[] ret=null;
            Object loopvalue=null; 
            if (ArrayOperators.IndexOf(Operator,StringComparison.OrdinalIgnoreCase) < 0)
            {
                if (OpA is Object[]) OpA = ((Object[])OpA).ToList();
                if (OpB is Object[]) OpB = ((Object[])OpB).ToList();
                if (OpA is List<Object>)
                {
                    var Enumcast = (IEnumerable<Object>)OpA;
                    var earray = Enumcast.ToArray();
                    ret = new object[Enumcast.Count()];
                    for (int i = 0; i < ret.Count() ; i++)
                    {
                        ret[i] = HandleOperator(Operator, earray[i], OpB);



                    }


                    return ret;

                }
                else if (OpB is List<Object>)
                {

                    var Enumcast = (IEnumerable<Object>)OpB;
                    var earray = Enumcast.ToArray();
                    ret = new object[Enumcast.Count()];
                    for (int i = 0; i < ret.Count(); i++)
                    {
                        ret[i] = HandleOperator(Operator, OpA,earray[i]);



                    }

                    return ret;
                }

            }
            //if either operand is still an array, we know that we are not dealing with
            //an array operator, so we will proceed by recursively calling this routine for each element, and creating a new array as a result.
            if (OpA is Object[] || OpB is Object[])
            {
                
                if (OpA is Object[]) //handles when both are object[] arrays, too.
                {
                    Object[] Castarray = (Object[])OpA;
                    Object[] returnvalues = new object[Castarray.Length];
                    //call for each item, and construct an array to return.
                    for (int i = 0; i < Castarray.Length; i++)
                    {
                        returnvalues[i] = HandleOperator(Operator, Castarray[i], OpB);


                    }
                    return returnvalues;
                }
                else if (OpB is Object[])
                {
                    Object[] Castarray = (Object[])OpB;
                    Object[] returnvalues = new object[Castarray.Length];
                    //call for each item, construct an array and return it.
                    for (int i = 0; i < Castarray.Length; i++)
                    {
                        returnvalues[i] = HandleOperator(Operator, OpA, Castarray[i]);

                    }
                    return returnvalues;
                }


            }
            else
            {



                switch (Operator.ToLower())
                {
                    case "^":
                        return Math.Pow((double) OpA, (double) OpB);

                    case "/":
                        return (double) OpA/(double) OpB;
                    case "\\":
                    case "div":
                        return Math.Floor((double) OpA/(double) OpB);
                    case "in":
                        return ((Object[]) OpB).Contains(OpA);
                    case "*":
                        return (double) OpA*(double) OpB;

                    case "+":
                        if ((OpA.GetType().Name == "String") || (OpB.GetType().Name == "String"))
                        {
                            return OpA + OpB.ToString();
                        }
                        else
                        {
                            double parseA, parseB;
                            if (double.TryParse(OpA.ToString(), out parseA))
                                if (double.TryParse(OpB.ToString(), out parseB))
                                    return parseA + parseB;
                        }
                        return null;

                    case "-":
                        return (double) OpA - (double) OpB;
                    case "$$":
                        //throw new NotImplementedException();
                        var rx = new Regex((string) OpB);
                        return rx.Match((String) OpA);

                    default:
                        return null;
                }
            }
            return null;
        }
        private CParser GetParserObject()
        {

            foreach (var itemloop in mPluginEvents)
            {
                Object returnvalue = itemloop.Invoke(this, PluginEventTypeConstants.PET_REQUESTPARSER);
                if (returnvalue != null)
                    return (CParser)returnvalue;
            }
            //(CParser)mPluginEvents(this, PluginEventTypeConstants.PET_REQUESTPARSER);
            return null;

        }

        public object HandleFunction(string FuncName, List<object> pparameters)
        {
            Debug.Print("HandleFunction:" + FuncName + "parameters:" + pparameters);
            //convert any Array's within tthis pparameters list into a List...
            List<object> parameters = (from ix in pparameters select ((ix.GetType().IsArray)?((Object[])ix).ToList():ix)).ToList();
            

            if (ArrayAwareFunctions.IndexOf(FuncName, StringComparison.OrdinalIgnoreCase) == -1 &&
                parameters.Any((w)=>w is List<Object>))
            {
                List<Object> parms = parameters;
                List<Object> firstlist=null;
                int firstarrayindex = 0;
                //iterate through the parameters, saving a reference to the first (and ONLY the first) array argument.
                //we only do the first, because the intention is that the function call will recurse on this method and thus
                //have the same logic, so if there are further array arguments, they will be processed in the same manner (since they will
                //eventually be the "first" array in the list of parameters)

                for (int i = 0; i < parms.Count; i++)
                {

                    if (firstlist==null && parms[i] is List<Object> )
                    {

                        firstlist = ((List<Object>)parms[i]);
                        firstarrayindex=i;

                    }


                }
                //Now, using the parms array, create a new list of parameters for each element in that array.

                //iterate through each value in firstarray.
                Object[] Buildreturn = new object[firstlist.Count];
                int a = 0;
                foreach (Object loopparameter in firstlist)
                {
                    //create a new array...
                    List<Object> useparameters = parms;
                    //set the proper index to be the current scalar...
                    useparameters[firstarrayindex] = loopparameter;
                    //call the function.
                    Buildreturn[a] = HandleFunction(FuncName, useparameters);
                    a++;
                }
                return Buildreturn;






            }



            switch (FuncName.ToLower())
            {
                case "sin":
                    return Math.Sin((double) parameters[0]);

                case "cos":
                    return Math.Cos((double) parameters[0]);


                case "tan":
                    return Math.Tan((double) parameters[0]);

                case "sqr":
                    return Math.Sqrt((double) parameters[0]);
                case "log":
                    return Math.Log((double)parameters[0]);
                case "round":
                    return Math.Round((double)parameters[0], (int)parameters[1]);
                case "array":
                
                    return parameters;
                case "store":
                    CParser parserobject = GetParserObject();
                    

                    //store(variablename,variablevalue)
                    //Variable founditem = parserobject.Variables.Find((w)=>w.Name==parameters[0].ToString());
                    Variable founditem = parserobject.Variables[parameters[0].ToString()];
                    if(founditem!=null)
                    {
                        parserobject.Variables.Remove(founditem);
                       

                    }
                    parserobject.Variables.Add((String)parameters[0], parameters[1]);
                    return parameters[1];
                    
                case "createobject":
                    if (parameters.Count() == 0)
                        throw new ArgumentException("CreateObject requires at least 1 argument");
                    
                    object returnobject = CParser.CreateCOMObject((string)parameters[0]);
                    if(returnobject==null)
                    {
                        //returnobject=Activator.CreateInstance(AssemblyName,typeName,Binder,args[],Cultureinfo culture)

                        String lAsmName = (String)parameters[0];
                        String mTypename=(String)parameters[1];
                        object[] constructorargs=parameters.GetRange(2,parameters.Count()-2).ToArray();

                        ObjectHandle objhandle = Activator.CreateInstance(lAsmName, mTypename, true, BindingFlags.CreateInstance, null, constructorargs, CultureInfo.CurrentCulture, null, null);
                        return objhandle.Unwrap();
                    }
                    return null;
                
                default:
                    return null;
            }
        }

        public bool CanHandleFunction(string FuncName, ref bool[] noparsedargs)
        {
            //noparsedargs=new bool[
            if(FuncName.Equals("store",StringComparison.OrdinalIgnoreCase))
                noparsedargs[0]=true;
            return (HandledFunctionString.IndexOf(" " + FuncName.ToLower() + " ") != -1);
        }

        public int CanHandleOperator(string Operator, out operatortypeconstants optype)
        {
            
            int binaryops = HandledOperatorString.IndexOf(" " + Operator + " ") + 1;
            int prefixops = HandledPrefixOps.IndexOf(" " + Operator + " ") + 1;
            int postfixops = HandledPostfixOps.IndexOf(" " + Operator + " ") + 1;
            int ret = 0;
            optype = operatortypeconstants.operator_binary;
            if (binaryops != 0)
            {
                optype = operatortypeconstants.operator_binary;
                ret = binaryops;
            }
            if (prefixops != 0)
            {
                optype = (operatortypeconstants) (((int) optype) & (int) (operatortypeconstants.operator_unary_prefix));

                ret += prefixops;
            }
            if (postfixops != 0)
            {
                optype = (operatortypeconstants) (((int) optype) & (int) (operatortypeconstants.operator_unary_postfix));
                ret += postfixops;
            }
            //return +1; so that -1 (not found) becomes 0 and everything else becomes positive. 0 is not found, anything else represents a priority 
            //of the operator. (lower means higher priority) 
            return ret;
        }

        public string getHandledFunctions()
        {
            return HandledFunctionString;
        }

        public string getHandledOperators(operatortypeconstants requesttype)
        {
            StringBuilder buildreturn=new StringBuilder();
            if ((requesttype & operatortypeconstants.operator_binary)==operatortypeconstants.operator_binary )
            {
                buildreturn.Append(HandledOperatorString);
            }
            if ((requesttype & operatortypeconstants.operator_unary_prefix) == operatortypeconstants.operator_unary_prefix)
            {
                buildreturn.Append(" " + HandledPrefixOps);
            }
            if ((requesttype & operatortypeconstants.operator_unary_postfix) == operatortypeconstants.operator_unary_postfix)
            {
                buildreturn.Append(" " + HandledPostfixOps);
            }
            return buildreturn.ToString();
        }

        public List<PluginEvent> EventDelegates
        {
            get { return mPluginEvents; }
            set { mPluginEvents = value; }
        }

        public object HandleUnaryOperation(string Operator, object Operand, operatortypeconstants optype)
        {
            //throw new NotImplementedException();
            switch (Operator.ToUpper())
            {
                case "-":
                    if(typeof(System.Double) == Operand.GetType())
                    {
                        return -(double)Operand;

                    }
                    else if (typeof(System.String)==Operand.GetType())
                    {
                        return ((String)Operand).Reverse();

                    }

                break;
                case "!":
                return factorial(Convert.ToInt32(Operand));
            }
            return null;
        }


        public object HandleSubscript(object onvalue, object[] parameters)
        {
            //throw new NotImplementedException();
            //Debug.Print("CoreOpFunc 'HandleSubscript' called.");
            //return null;
            if ((typeof (String)).Equals(onvalue.GetType()))
            {
                var onstring = (String) onvalue;
                int index = int.Parse(parameters[0].ToString());
                if (parameters.Length == 1)
                    return onstring[index];
                else
                {
                    int lengthuse = int.Parse(parameters[1].ToString());
                    return onstring.Substring(index, lengthuse);
                }
            }
            else 
            {
                //assume your standard array...
                //object[] test;
                //test.GetValue(int indices[])
                object[] objuse = (object[])onvalue;
                var  indices= new int[parameters.Count()];
                //parameters.Select((w, y) => indices[y] = (int)w );
                for (int i = 0; i < indices.Length; i++)
                    indices[i] = Convert.ToInt32(parameters[i]);
                    

                return objuse.GetValue(indices);



            }
            
        }


        public object HandleInvocation(object OnObject, string routinename, object[] parameters)
        {
            IEnumerable<MethodInfo> invokethis = from p in (OnObject.GetType().GetMethods())
                                                 where p.Name.Equals(routinename, StringComparison.OrdinalIgnoreCase)
                                                 select p;
            if (invokethis.Count() > 0)
            {
                foreach (MethodInfo loopmethod in invokethis)
                {
                    if (loopmethod.GetParameters().Length == parameters.Count())
                    {
                        object returnvalue = null;
                        returnvalue = loopmethod.Invoke(OnObject, parameters.ToArray());
                        if (returnvalue != null)
                            return returnvalue;
                        //methodcalled = true;
                    }
                }
            }
            else if(parameters.Count()==0)
            {
                IEnumerable<PropertyInfo> objprops = from p in (OnObject.GetType().GetProperties())
                                                     where
                                                         p.Name.Equals(routinename, StringComparison.OrdinalIgnoreCase)
                                                     select p;
                if (objprops.Count() > 0)
                {
                    foreach (PropertyInfo propinfo in objprops)
                    {
                        object returnproperty = propinfo.GetGetMethod().Invoke(OnObject, parameters.ToArray());
                        if (returnproperty!=null)
                            return returnproperty;

                    }


                }



            }
            else
            {
                return null;
            }



            return null;
        }

        #endregion
    }
}