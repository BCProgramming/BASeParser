﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BASeParser
{
    /// <summary>
    /// Class used to allow for Indexing to use the name of the variable. and a few other things.
    /// </summary>
    public class VariableList : IEnumerable<Variable>
    {

        //events...
        public enum VariableListBeforeEventReturnConstants
        {
            /// <summary>
            /// VL_ALLOW: "accepts" that the event will occur (approves the add or remove)
            /// </summary>
            VL_ALLOW,
            /// <summary>
            /// VL_DENY: denies the change. later invocations may change this value.
            /// </summary>
            VL_DENY,
            

        }

        

        public delegate void SingleArgFunction(Variable variablearg);
        public event Func<Variable, VariableListBeforeEventReturnConstants> BeforeVariableAdd;
        public event Func<Variable, VariableListBeforeEventReturnConstants> BeforeVariableRemove;
        public event SingleArgFunction VariableAdded;
        public event SingleArgFunction VariableRemoved;


        #region event helper routines...
        public void RaiseVariableAdded(Variable variablearg)
        {
            SingleArgFunction arguse = VariableAdded;
            if (arguse != null)
                arguse.Invoke(variablearg);




        }
        public void RaiseVariableRemoved(Variable variablearg)
        {
            SingleArgFunction arguse = VariableRemoved;
            if (arguse != null)
                arguse.Invoke(variablearg);



        }

        public VariableListBeforeEventReturnConstants RaiseBeforeVariableRemove(Variable addedvar)
        {
            VariableListBeforeEventReturnConstants currentreturn;
            VariableListBeforeEventReturnConstants currreturn;
            currreturn = VariableListBeforeEventReturnConstants.VL_DENY;
            Delegate[] invokelist;
            Func<Variable, VariableListBeforeEventReturnConstants> addobj = BeforeVariableRemove;
            if (addobj != null)
            {
                invokelist = addobj.GetInvocationList();
                foreach (Func<Variable, VariableListBeforeEventReturnConstants> loopinvoke in invokelist)
                {
                    currentreturn = loopinvoke.Invoke(addedvar);
                    if (currentreturn == VariableListBeforeEventReturnConstants.VL_ALLOW)
                        currreturn = currentreturn;


                }






            }
            return currreturn;




        }

        public VariableListBeforeEventReturnConstants RaiseBeforeVariableAdd(Variable addedvar)
        {
             VariableListBeforeEventReturnConstants currentreturn;
             VariableListBeforeEventReturnConstants currreturn;
            currreturn =  VariableListBeforeEventReturnConstants.VL_DENY ;
            Delegate[] invokelist;
            Func<Variable,  VariableListBeforeEventReturnConstants> addobj = BeforeVariableAdd;
            if (addobj != null)
            {
                invokelist = addobj.GetInvocationList();
                foreach (Func<Variable,  VariableListBeforeEventReturnConstants> loopinvoke in invokelist)
                {
                    currentreturn = loopinvoke.Invoke(addedvar);
                    if(currentreturn==VariableListBeforeEventReturnConstants.VL_ALLOW)
                        currreturn = currentreturn;


                }






            }
            return currreturn;




        }



        #endregion 
        /// <summary>
        /// Private List used to actually hold variables.
        /// </summary>
        private List<Variable> mList;

        public VariableList()
        {
            mList = new List<Variable>();
        }

        public VariableList(VariableList Otherlist)
        {
            mList = new List<Variable>(Otherlist);
        }

        public Variable this[int Index]
        {
            get { return mList[Index]; }
            set { mList[Index] = value; }
        }

        public Variable Add(String Name, Object Value)
        {
            Variable addthis = new Variable(Name, Value);
            mList.Add(addthis);
            return addthis;
        }

        public void Remove(String Name)
        {
            Variable removethis = mList.Find((w) => w.Name.Equals(Name, StringComparison.OrdinalIgnoreCase));
            mList.Remove(removethis);
        }

        public void Remove(Variable removeitem)
        {
            mList.Remove(removeitem);
        }

        public bool Exists(String Name)
        {
            return mList.Exists((w) => w.Name.Equals(Name, StringComparison.OrdinalIgnoreCase));
        }

        public Variable this[String index]
        {
            get { return mList.Find((w) => w.Name.Equals(index, StringComparison.OrdinalIgnoreCase)); }
            set
            {
                int foundindex = mList.FindIndex((w) => w.Name.Equals(value.Name, StringComparison.OrdinalIgnoreCase));
                mList[foundindex] = value;
            }
        }

        #region IEnumerable<Variable> Members

        public IEnumerator<Variable> GetEnumerator()
        {
            // throw new NotImplementedException();
            return mList.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return mList.GetEnumerator();
        }

        #endregion
    }
}