﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BASeParser
{
    /// <summary>
    /// when implemented, allows objects to explicitly define various ways they can be used within a baseparser expression.
    /// </summary>
    interface IOperable
    {
        
    }
}
