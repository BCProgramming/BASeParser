﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BASeParser
{
    class SObject
    {
        public Object Value { get; set; }
        public SObject(Object value)
        {
            Value = value;

        }

        
    }
}
